Thank you for downloading the project! 

If you need halp with the install contact me on github.

Install:
  1.Instal unity package and put the prefab on your Avatar.
  1a. Add contacts to allow grow or shrink on contact with "Grow" or "Shrink" as the Paramater name and make sure contact type is on entry.
  (Note)-Included image is a simple contact example with grow or shrink changing what it does.
  2.Install Python 3.14.
  3.Install Python OSC library using "pip install python-osc" in terminal of choice.

Operation:
 When using make sure to have the python script running before changing into the avatar or weird side effects may occur!
 You must have the script running when using that avatar with the scaler else it won't work.

Final Note:
 Sorry if this is hard to understand if you need help don't be afraid to reach out on github. 
 This script may be real buggy and sorry in advance for that VRC is a tad buggy.