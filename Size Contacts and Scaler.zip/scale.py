from pythonosc import udp_client
from pythonosc.dispatcher import Dispatcher
from pythonosc.osc_server import BlockingOSCUDPServer

import time

VRC_IP = "127.0.0.1"
VRC_PORT = 9000 
VRC_PORT2 = 9001

height = 1.0

def filter_handler(address, *args): #Gets Current height
    global height
    height = float(*args)

def filter_handler2(address, *args): #Grow contact script
        global height
        if(bool(*args)==True):
            height = height*1.03
            client.send_message("/avatar/eyeheight",float(height))
            print("Growed to " + str(height))
            time.sleep(0.1)

def filter_handler3(address, *args): #Shrink contact script
        global height
        if(bool(*args)==True):
            height = height*0.97
            client.send_message("/avatar/eyeheight",float(height))
            print("Growed to " + str(height))
            time.sleep(0.1)

def default_handler(address, *args):
      global height
      spurts = 20 #How many growth spurts per second
      growT = float(5) #Time to Resize
      
      if(address == "/avatar/parameters/Scaler_H" or str(address) == "/avatar/parameters/Small_Scaler"):
        x = float(*args)
        i = 0
        spurts = spurts * growT
        growT = growT / spurts
        if(round(x)==255):
          x = 1000

        elif(round(x)==254):
          x = 500

        if((x<=0)or(x==height)):
          time.sleep(0.1)

        elif(height > x): #Shrink Scaler
          diffrence = height - x
          interval = diffrence/float(spurts)
          while(i<spurts):
               height = height - interval
               client.send_message("/avatar/eyeheight",float(height))
               i = i + 1
               time.sleep(growT)
          print("Shrunk to " + str(height))
        
        elif(height < x): #Grow Scaler
          diffrence = x - height
          interval = diffrence/float(spurts)
          while(i<spurts):
               height = height + interval
               client.send_message("/avatar/eyeheight",float(height))
               i = i + 1
               time.sleep(growT)
          print("Grown to " + str(height))

dispatcher = Dispatcher()
dispatcher.map("/avatar/eyeheight", filter_handler)
dispatcher.map("/avatar/parameters/Grow", filter_handler2)
dispatcher.map("/avatar/parameters/Shrink", filter_handler2)
dispatcher.set_default_handler(default_handler)

server = BlockingOSCUDPServer((VRC_IP, VRC_PORT2), dispatcher)
client = udp_client.SimpleUDPClient(VRC_IP, VRC_PORT)

server.serve_forever()