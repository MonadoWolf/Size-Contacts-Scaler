from pythonosc import udp_client
from pythonosc.dispatcher import Dispatcher
from pythonosc.osc_server import BlockingOSCUDPServer

import time
import threading

VRC_IP = "127.0.0.1"
VRC_PORT = 9000 
VRC_PORT2 = 9001

height = 1.0
slowChange = False
client = udp_client.SimpleUDPClient(VRC_IP, VRC_PORT)

def filter_handler(address, *args): #Gets Current height
    global height
    height = float(*args)

def filter_handler2(address, *args): #Grow contact script
    global height
    if(bool(*args)==True):
        height = height*1.03
        client.send_message("/avatar/eyeheight",float(height))
        print("Growed to " + str(height))


def filter_handler3(address, *args): #Shrink contact script
    global height
    if(bool(*args)==True):
        height = height*0.97
        client.send_message("/avatar/eyeheight",float(height))
        print("Growed to " + str(height))

def filter_handler4(address, *args):
    global height
    spurts = 30 #How many growth spurts per second
    growT = float(4) #Time to Resize
    x = float(*args)
    i = 0
    spurts = int(spurts) * int(growT)
    growT = growT / spurts
    if(round(x)==255): #Lines 42 to 61 are special cases
        x = 1000

    elif(round(x)==254):
        x = 500

    elif(round(x)==2):
        x = 0.01

    elif(round(x)==3):
        x = 0.1

    elif(round(x)==4):
        x = 0.3

    elif(round(x)==5):
        x = 0.5

    elif(x <= 0.001):
        x = 0

    if((x<=0)or(x==height)):
        time.sleep(0.001)

    elif(height > x): #Shrink Scaler
        diffrence = height - x
        interval = diffrence/float(spurts)
        while(i<spurts):
            height = height - interval
            client.send_message("/avatar/eyeheight",float(height))
            i = i + 1
            time.sleep(growT)
        print("Shrunk to " + str(height))
        
    elif(height < x): #Grow Scaler
        diffrence = x - height
        interval = diffrence/float(spurts)
        while(i<spurts):
            height = height + interval
            client.send_message("/avatar/eyeheight",float(height))
            i = i + 1
            time.sleep(growT)
        print("Grown to " + str(height))

def filter_handler5(address, *args): #constant scaler
    global slowChange
    if(bool(*args) == True):
        slowChange = True
        thread = threading.Thread(target = constantChange)
        thread.start()
    else:
        slowChange = False

def run(address,*args):
    thread = threading.Thread(target = filter_handler4, args = ["egg",*args])
    thread.start()

def constantChange(): #Slow Contact Scaler
    global slowChange
    global height
    while(slowChange):
        height = height * 1.005 #How strong you want to grow/shrink
        client.send_message("/avatar/eyeheight",float(height))
        time.sleep(0.05)

def assignScale(dis):
    dis.map("/avatar/eyeheight", filter_handler)
    dis.map("/avatar/parameters/Grow", filter_handler2)
    dis.map("/avatar/parameters/Shrink", filter_handler3)
    dis.map("/avatar/parameters/Scaler_H", run)
    dis.map("/avatar/parameters/CScale", filter_handler5)

if __name__ == "__main__":
    dispatcher = Dispatcher()
    assignScale(dispatcher)
    server = BlockingOSCUDPServer((VRC_IP, VRC_PORT2), dispatcher)

    server.serve_forever()